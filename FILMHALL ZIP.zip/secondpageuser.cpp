#include "secondpageuser.h"
#include "ui_secondpageuser.h"

secondpageuser::secondpageuser(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::secondpageuser)
{
    ui->setupUi(this);
}

secondpageuser::~secondpageuser()
{
    delete ui;
}
