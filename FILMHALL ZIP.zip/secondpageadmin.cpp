#include "secondpageadmin.h"
#include "ui_secondpageadmin.h"
#include <QMessageBox>

secondpageadmin::secondpageadmin(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::secondpageadmin)
{
    ui->setupUi(this);
}

secondpageadmin::~secondpageadmin()
{
    delete ui;
}

void secondpageadmin::on_login_clicked()
{
    QString username = ui->lineEdit_username->text();
    QString password = ui->lineEdit_password->text();

    if (username == "CinemaXx" && password == "Cinequad"){

        hide();
        adminlogin=new class adminlogin(this);
        adminlogin->show();
    }
    else QMessageBox::warning(this,"LOGIN","Username or Password is incorrect");
}

