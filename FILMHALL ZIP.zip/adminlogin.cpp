#include "adminlogin.h"
#include "ui_adminlogin.h"

adminlogin::adminlogin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::adminlogin)
{
    ui->setupUi(this);

    // Optional: make it behave like a normal window
    setWindowFlags(Qt::Window
                   | Qt::WindowMinimizeButtonHint
                   | Qt::WindowMaximizeButtonHint
                   | Qt::WindowCloseButtonHint);
}

adminlogin::~adminlogin()
{
    delete ui;
}
