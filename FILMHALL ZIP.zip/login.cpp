#include "login.h"
#include "ui_login.h"

login::login(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::login)
{
    ui->setupUi(this);

    setWindowFlags(Qt::Window
                   | Qt::WindowMinimizeButtonHint
                   | Qt::WindowMaximizeButtonHint
                   | Qt::WindowCloseButtonHint);

}

login::~login()
{
    delete ui;
}

/*void login::on_pushbuttoncostumer_clicked()
{
    secondpageuser secondpageuser;
    secondpageuser.setModal (true);
    secondpageuser.exec();
}

void login::on_Pushbuttonadmin_clicked()
{
    secondpageadmin secondpageadmin;
    secondpageadmin.setModal (true);
    secondpageadmin.exec();
}

*/
void login::on_pushbuttoncustomer_clicked()
{   hide();
    secondpageuser = new class secondpageuser(this);
    secondpageuser->showMaximized();
}
void login::on_Pushbuttonadmin_clicked()
{   hide();
    secondpageadmin = new class secondpageadmin(this);
    secondpageadmin->showMaximized();
}
