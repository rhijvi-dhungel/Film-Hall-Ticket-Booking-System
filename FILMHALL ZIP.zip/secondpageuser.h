#ifndef SECONDPAGEUSER_H
#define SECONDPAGEUSER_H

#include <QDialog>

namespace Ui {
class secondpageuser;
}

class secondpageuser : public QDialog
{
    Q_OBJECT

public:
    explicit secondpageuser(QWidget *parent = nullptr);
    ~secondpageuser();

private:
    Ui::secondpageuser *ui;
};

#endif // SECONDPAGEUSER_H
